# EDU Chain App

## Installation

```bash
forge build
forge create MyCounter --fork-url $EDUCHAIN_RPC_URL --private-key $PRIVATE_KEY --broadcast
```

connect to the network
```bash
forge create Hello_World --rpc-url $EDUCHAIN_RPC_URL --private-key $PRIVATE_KEY --broadcast --consturctor-args

forge build
```
